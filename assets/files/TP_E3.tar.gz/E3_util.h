#ifndef E3_UTIL_H
#define E3_UTIL_H

#include <stdio.h>
#include <stdlib.h>

/* =========================================================
 * Types — cohérents avec le TP C4.
 * ========================================================= */

/* --- Liste chaînée de réels --- */
typedef struct tmp_maillon {
    double               contenu;
    struct tmp_maillon * suivant;
} Maillon;
typedef Maillon *   PtrMaillon;
typedef PtrMaillon  Liste;

/* --- Tableau dynamique d'entiers ---
 * Note : enrichi par rapport au TP C4 (ajout de taille/capacite)
 * pour pouvoir mesurer les opérations d'insertion. */
typedef struct {
    int * donnees;   /* bloc contigu d'entiers  */
    int   taille;    /* nombre d'éléments stockés */
    int   capacite;  /* nombre de cases allouées  */
} TabDyn;

/* =========================================================
 * Prototypes — liste chaînée.
 * ========================================================= */
double     tempsSecondes(void);

int        listeVide(Liste pL);
void       afficheListe(Liste pL);                           /* récursive */
PtrMaillon creeMaillon(double pContenu, PtrMaillon pSuivant);
Liste      ajouteDebut(Liste pL, PtrMaillon pPM);
Liste      ajouteFin(Liste pL, PtrMaillon pPM);              /* récursive */
int        contient(Liste pL, double pVal);
Liste      supprimePremier(Liste pL);                        /* avec free */
Liste      supprimeDernier(Liste pL);                        /* avec free */
void       libereListe(Liste * pL);
Liste      creerListeAleatoire(int pN);

/* =========================================================
 * Prototypes — tableau dynamique.
 * ========================================================= */
TabDyn creerTab(int pCapacite);
void   libereTab(TabDyn * pT);
void   afficheTab(TabDyn pT);

#endif /* E3_UTIL_H */
