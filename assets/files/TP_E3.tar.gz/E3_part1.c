#include "E3_util.h"
#include <stdio.h>
#include <stdlib.h>

/* =========================================================
 * Exercice 1 — Prise en main des fichiers utilitaires.
 *
 * Compilation :
 *   mycc -c E3_util.c                   (produit E3_util.o)
 *   mycc E3_part1.c E3_util.o -o part1.x
 *   ./part1.x
 * ========================================================= */
int main(void) {
    srand(42);

    printf("=== Test liste vide ===\n");
    Liste vL = NULL;
    printf("listeVide(NULL) = %d  (attendu 1)\n", listeVide(vL));
    afficheListe(vL);

    printf("\n=== Test creeMaillon + ajouteDebut ===\n");
    vL = ajouteDebut(vL, creeMaillon(3));
    vL = ajouteDebut(vL, creeMaillon(7));
    vL = ajouteDebut(vL, creeMaillon(2));
    afficheListe(vL);  /* |2|->|7|->|3|->NULL */
    printf("listeVide = %d  (attendu 0)\n", listeVide(vL));

    printf("\n=== Test ajouteFin ===\n");
    vL = ajouteFin(vL, creeMaillon(5));
    afficheListe(vL);  /* |2|->|7|->|3|->|5|->NULL */

    printf("\n=== Test contient ===\n");
    printf("contient(2)=%d contient(7)=%d contient(9)=%d  (attendu 1 1 0)\n",
           contient(vL, 2), contient(vL, 7), contient(vL, 9));

    printf("\n=== Test supprimePremier ===\n");
    vL = supprimePremier(vL);
    afficheListe(vL);  /* |7|->|3|->|5|->NULL */

    printf("\n=== Test supprimeDernier ===\n");
    vL = supprimeDernier(vL);
    afficheListe(vL);  /* |7|->|3|->NULL */

    printf("\n=== Test libereListe ===\n");
    libereListe(&vL);
    printf("Après libereListe : ");
    afficheListe(vL);  /* NULL */

    printf("\n=== Test creerListeAleatoire (5 éléments) ===\n");
    Liste vL2 = creerListeAleatoire(5);
    afficheListe(vL2);
    libereListe(&vL2);

    printf("\n=== Test tableau dynamique ===\n");
    TabDyn vT = creerTab(5);
    vT.donnees[0] = 10; vT.donnees[1] = 20; vT.donnees[2] = 30;
    vT.taille = 3;
    afficheTab(vT);   /* [10, 20, 30] */
    libereTab(&vT);
    printf("Après libereTab : taille=%d capacite=%d\n", vT.taille, vT.capacite);

    return 0;
} /* main() */
