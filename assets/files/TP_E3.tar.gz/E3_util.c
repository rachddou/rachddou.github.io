#define _POSIX_C_SOURCE 200809L
#include "E3_util.h"
#include <time.h>

/* =========================================================
 * Mesure du temps (résolution nanoseconde).
 * ========================================================= */
double tempsSecondes(void) {
    struct timespec vTs;
    clock_gettime(CLOCK_MONOTONIC, &vTs);
    return vTs.tv_sec + vTs.tv_nsec * 1e-9;
} /* tempsSecondes() */

/* =========================================================
 * Fonctions sur les listes chaînées — style TP C4.
 * ========================================================= */

int listeVide(Liste pL) {
    return pL == NULL;
} /* listeVide() */

/* Affichage récursif : |3.00|->|7.00|->|2.00|->NULL */
void afficheListe(Liste pL) {
    if (pL == NULL) { printf("NULL\n"); return; }
    printf("|%.2f|->", pL->contenu);
    afficheListe(pL->suivant);
} /* afficheListe() */

/* Alloue et initialise un maillon — deux arguments comme en TP C4. */
PtrMaillon creeMaillon(double pContenu, PtrMaillon pSuivant) {
    PtrMaillon vP = (PtrMaillon)malloc(sizeof(Maillon));
    if (vP == NULL) return NULL;
    vP->contenu = pContenu;
    vP->suivant = pSuivant;
    return vP;
} /* creeMaillon() */

/* Chaîne pPM en tête de pL et retourne la nouvelle tête. */
Liste ajouteDebut(Liste pL, PtrMaillon pPM) {
    if (pPM == NULL) return pL;
    pPM->suivant = pL;
    return pPM;
} /* ajouteDebut() */

/* Chaîne pPM en queue de pL — récursif comme en TP C4. */
Liste ajouteFin(Liste pL, PtrMaillon pPM) {
    if (listeVide(pL)) return pPM;
    pL->suivant = ajouteFin(pL->suivant, pPM);
    return pL;
} /* ajouteFin() */

int contient(Liste pL, double pVal) {
    for (PtrMaillon p = pL; p != NULL; p = p->suivant)
        if (p->contenu == pVal) return 1;
    return 0;
} /* contient() */

/* Supprime et libère le premier maillon ; retourne la nouvelle tête. */
Liste supprimePremier(Liste pL) {
    if (listeVide(pL)) return NULL;
    PtrMaillon vSuiv = pL->suivant;
    free(pL);
    return vSuiv;
} /* supprimePremier() */

/* Supprime et libère le dernier maillon ; retourne la (nouvelle) tête. */
Liste supprimeDernier(Liste pL) {
    if (listeVide(pL)) return NULL;
    if (pL->suivant == NULL) { free(pL); return NULL; }
    PtrMaillon p = pL;
    while (p->suivant->suivant != NULL)
        p = p->suivant;
    free(p->suivant);
    p->suivant = NULL;
    return pL;
} /* supprimeDernier() */

/* Libère tous les maillons et met le pointeur de tête à NULL. */
void libereListe(Liste * pL) {
    while (!listeVide(*pL))
        *pL = supprimePremier(*pL);
} /* libereListe() */

/* Crée une liste de pN éléments aléatoires dans [0, 999].
 * Construction itérative O(n) avec pointeur de queue —
 * n'utilise pas ajouteFin (récursif O(n)) pour rester en O(n). */
Liste creerListeAleatoire(int pN) {
    Liste      vTete  = NULL;
    PtrMaillon vQueue = NULL;
    for (int i = 0; i < pN; i++) {
        PtrMaillon vP = creeMaillon(rand() % 1000, NULL);
        if (vP == NULL) return vTete;
        if (listeVide(vTete)) {
            vTete = vP;
        } else {
            vQueue->suivant = vP;
        }
        vQueue = vP;
    }
    return vTete;
} /* creerListeAleatoire() */

/* =========================================================
 * Fonctions sur les tableaux dynamiques.
 * ========================================================= */

TabDyn creerTab(int pCapacite) {
    TabDyn vT;
    vT.donnees  = (int *)malloc(pCapacite * sizeof(int));
    vT.taille   = 0;
    if (vT.donnees != NULL)
        vT.capacite = pCapacite;
    else
        vT.capacite = 0;
    return vT;
} /* creerTab() */

void libereTab(TabDyn * pT) {
    free(pT->donnees);
    pT->donnees  = NULL;
    pT->taille   = 0;
    pT->capacite = 0;
} /* libereTab() */

void afficheTab(TabDyn pT) {
    printf("[");
    for (int i = 0; i < pT.taille; i++) {
        printf("%d", pT.donnees[i]);
        if (i < pT.taille - 1) printf(", ");
    }
    printf("]\n");
} /* afficheTab() */
