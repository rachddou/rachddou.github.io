// fichier: Somme.java
public class Somme {
    public static void main(String[] args) {
        // test sur les paramètres de la fonction
        if (args.length < 1) {
            System.err.println("Usage: java Somme <n>");
            return;
        }

        // conversion de la chaine de caractère en un entier
        long n;
        try {
            n = Long.parseLong(args[0]);
        } catch (NumberFormatException e) {
            System.err.println("Erreur: n doit être un entier.");
            return;
        }

        if (n < 1) {
            System.err.println("Erreur: n doit être un entier positif.");
            return;
        }

        // déclaration et initialisation de variable pour mesurer le temps d'execution
        long t0 = System.nanoTime();

        // coeur de la fonction
        long s = 0;
        for (long i = 1; i <= n; i++) s += i;

        // calcul du temps d'execution
        double dt = (System.nanoTime() - t0) / 1e9;
        System.out.println("Résultat : " + s);
        System.out.printf("Temps    : %.6f s%n", dt);
    }
}