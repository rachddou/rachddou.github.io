# fichier: somme.py
import sys
import time

# test sur les paramètres de la fonction
if len(sys.argv) < 2:
    print(f"Usage: {sys.argv[0]} <n>", file=sys.stderr)
    raise SystemExit(1)

# conversion de la chaine de caractère en un entier
try:
    n = int(sys.argv[1])
except ValueError:
    print("Erreur: n doit être un entier.", file=sys.stderr)
    raise SystemExit(1)

if n < 1:
    print("Erreur: n doit être un entier positif.", file=sys.stderr)
    raise SystemExit(1)

# déclaration et initialisation de variable pour mesurer le temps d'execution
t0 = time.perf_counter()

# coeur de la fonction
s = 0
for i in range(1, n + 1):
    s += i

# calcul du temps d'execution
dt = time.perf_counter() - t0

print(f"Résultat : {s}")
print(f"Temps    : {dt:.6f} s")