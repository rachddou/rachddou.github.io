// fichier: somme.c
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main(int argc, char *argv[]) {
    // test sur les paramètres de la fonction
    if (argc < 2) {
        fprintf(stderr, "Usage: %s <n>\n", argv[0]);
        return 1;
    }

    // conversion de la chaine de caractère en un entier.
    long long n = atoll(argv[1]);
    if (n < 1) {
        fprintf(stderr, "Erreur: n doit être un entier positif.\n");
        return 1;
    }

    // déclaration et initialisation de variable pour mesurer le temps d'éxecution
    struct timespec t0, t1;
    clock_gettime(CLOCK_MONOTONIC, &t0);

    // coeur de la fonction
    long long s = 0;
    for (long long i = 1; i <= n; i++) {
        s += i;}
     
    // calcul du temps d'éxecution
    clock_gettime(CLOCK_MONOTONIC, &t1);
    double dt = (t1.tv_sec - t0.tv_sec) + (t1.tv_nsec - t0.tv_nsec) / 1e9;
    printf("Résultat : %lld\n", s);
    printf("Temps    : %.9f s\n", dt);
    return 0;
}