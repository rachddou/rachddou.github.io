from time import time
import tracemalloc


def fibonnaci_iteratif(n):
    """
    =======================
    ======A REMPLIR =======
    =======================
    coder une fonction avec une boucle for pour 
    calculer le n-ième terme de la suite de Fibonnaci.
    """
    if n == 0:
        return 1
    if n == 1:
        return 1

    a, b = 1, 1
    for _ in range(2, n + 1):
        a, b = b, a + b
    return b

def fibonnaci_recursif(n):
    """
    =======================
    ======A REMPLIR =======
    =======================
    coder une fonction récursive (appel à elle-même) pour
    calculer le n-ième terme de la suite de Fibonnaci.
    """
    if n ==0:
        return 1
    if n == 1:
        return 1
    return fibonnaci_recursif(n - 1) + fibonnaci_recursif(n - 2)

if __name__ == "__main__":
    n = 20
    mode = "iteratif"  # ou "iteratif"

    fonctions = {
        "recursif": fibonnaci_recursif,
        "iteratif": fibonnaci_iteratif,
    }

    func = fonctions[mode]

    tracemalloc.start()
    start_time = time()
    result = func(n)
    finish_time = time()
    current, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()


    print(f"Résultat : {result}")
    print(f"Pour n={n} en mode '{mode}' : {finish_time - start_time:.6f}s")
    print(f"Pic tracemalloc : {peak / 1024:.2f} KB")
