from time import perf_counter
import matplotlib.pyplot as plt
from fibonnaci_élève_corrigé import fibonnaci_iteratif, fibonnaci_recursif


def mesurer_temps(fonction, n):
	debut = perf_counter()
	fonction(n)
	fin = perf_counter()
	return fin - debut


def tracer_courbe(log_scale: bool = True):
	# On limite n pour que la version récursive reste raisonnable en durée.
	n_values = list(range(1, 36))

	temps_iteratif = [mesurer_temps(fibonnaci_iteratif, n) for n in n_values]
	temps_recursif = [mesurer_temps(fibonnaci_recursif, n) for n in n_values]

	plt.figure(figsize=(10, 6))
	plt.plot(n_values, temps_iteratif, marker="o", label="Itératif")
	plt.plot(n_values, temps_recursif, marker="s", label="Récursif")

	if log_scale:
		plt.xscale("log")  # Échelle logarithmique pour mieux visualiser les différences

	plt.xlabel("n")
	plt.ylabel("Temps d'exécution (secondes)")
	scale_label = "échelle log" if log_scale else "échelle linéaire"
	plt.title(f"Comparaison des temps d'exécution Fibonacci ({scale_label})")
	plt.grid(True, which="both", linestyle="--", alpha=0.5)
	plt.legend()
	plt.tight_layout()

	suffix = "log" if log_scale else "lineaire"
	output_file = f"courbe_temps_fibonnaci_{suffix}.png"
	plt.savefig(output_file, dpi=150)
	print(f"Courbe enregistrée dans : {output_file}")


if __name__ == "__main__":
	tracer_courbe(log_scale=True)
