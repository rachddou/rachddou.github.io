from time import time
import tracemalloc

def recherche_lineaire(liste, cible):
    """
    =======================
    ======A REMPLIR =======
    =======================
    coder la fonction de recherche naïve de la cible dans la liste.
    On parcourera la liste dans son entièreté, jusqu'à trouver l'élément.
    """
    pass # supprimer avant de coder

def recherche_dichotomique(liste, cible):
    """
    =======================
    ======A REMPLIR =======
    =======================
    coder la fonction de recherche dichotomique de la cible dans la liste.
    """
    pass # supprimer avant de coder


if __name__ == "__main__":
    import random

    n = 100000
    mode = "lineaire"   # ou "dichotomique"
    pire_cas = False     # True = cible absente, False = cible présente (cas moyen)

    fonctions = {
        "lineaire": recherche_lineaire,
        "dichotomique": recherche_dichotomique,
    }

    liste = sorted(random.sample(range(10 * n), n))
    cible = -1 if pire_cas else random.choice(liste)

    func = fonctions[mode]

    tracemalloc.start()
    start_time = time()
    result = func(liste, cible)
    finish_time = time()
    current, peak = tracemalloc.get_traced_memory()
    tracemalloc.stop()


    print(f"Résultat : index={result}")
    print(f"Pour n={n} en mode '{mode}' ({'pire cas' if pire_cas else 'cas moyen'}) : {finish_time - start_time:.6f}s")
    print(f"Pic tracemalloc : {peak / 1024:.2f} KB")