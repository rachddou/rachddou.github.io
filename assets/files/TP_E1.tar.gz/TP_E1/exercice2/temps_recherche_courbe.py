from time import perf_counter
import random

import matplotlib.pyplot as plt
from recherche_élève import recherche_lineaire, recherche_dichotomique


def mesurer_temps_moyen(fonction, liste, cibles):
    """Mesure le temps moyen d'exécution sur plusieurs cibles."""
    total = 0.0
    for cible in cibles:
        debut = perf_counter()
        fonction(liste, cible)
        fin = perf_counter()
        total += fin - debut
    return total / len(cibles)


def tracer_courbe(
    max_n: int = 200_000,
    pas: int = 10_000,
    repetitions: int = 20,
    pire_cas: bool = True,
    log_scale: bool = True,
):
    """
    Compare les temps de recherche linéaire et dichotomique
    pour des listes triées de tailles croissantes.
    """
    random.seed(42)

    n_values = []
    temps_lineaire = []
    temps_dichotomique = []

    for n in range(pas, max_n + 1, pas):
        liste = sorted(random.sample(range(10 * n), n))

        if pire_cas:
            # Cible absente : pire cas pour les deux méthodes
            cibles = [-1] * repetitions
        else:
            # Cible présente : cas moyen (positions variées)
            cibles = [random.choice(liste) for _ in range(repetitions)]

        t_lin = mesurer_temps_moyen(recherche_lineaire, liste, cibles)
        t_dicho = mesurer_temps_moyen(recherche_dichotomique, liste, cibles)

        n_values.append(n)
        temps_lineaire.append(t_lin)
        temps_dichotomique.append(t_dicho)

    plt.figure(figsize=(10, 6))
    plt.plot(n_values, temps_lineaire, marker="o", label="Recherche linéaire")
    plt.plot(n_values, temps_dichotomique, marker="s", label="Recherche dichotomique")

    if log_scale:
        plt.xscale("log")

    plt.xlabel("Taille de la liste (n)")
    plt.ylabel("Temps d'exécution moyen (secondes)")
    cas = "pire cas" if pire_cas else "cas moyen"
    echelle = "échelle log" if log_scale else "échelle linéaire"
    plt.title(f"Comparaison des temps de recherche ({cas}, {echelle})")
    plt.grid(True, which="both", linestyle="--", alpha=0.5)
    plt.legend()
    plt.tight_layout()

    suffix_cas = "pire_cas" if pire_cas else "cas_moyen"
    suffix_echelle = "log" if log_scale else "lineaire"
    output_file = f"courbe_temps_recherche_{suffix_cas}_{suffix_echelle}.png"
    plt.savefig(output_file, dpi=150)
    print(f"Courbe enregistrée dans : {output_file}")


if __name__ == "__main__":
    tracer_courbe(
        max_n=100,
        pas=5,
        repetitions=20,
        pire_cas=True,
        log_scale=True,
    )
